
package Interfaces;

public interface IloginOperation 
{
    boolean matchAdmin(String var1, String var2);

    void matchUser();
}
